"""Tests for Hirevia."""
